Funcoes.somenteTransportadoresAutonomos()
def vaux = Lancamentos.valor(evento)
if (vaux > 0) {
    valorReferencia = vaux
    valorCalculado = vaux * 0.80
} else {
    valorReferencia = 0
    valorCalculado = autonomo.totalServicosAutonomo * 0.80
}
if (valorCalculado > 0) {
    Bases.compor(valorCalculado, Bases.INSS)
}
