Funcoes.somenteAposentadosPensionistas()
if (servidor.possuiMolestiaGrave) {
    suspender 'O evento não é calculado para pessoas que possuam moléstia grave'
}
if (!servidor.dataNascimento) {
    suspender 'O evento não é calculado para pessoas que não tenham data de nascimento informada'
}
def finalCpt = Datas.data(Datas.ano(calculo.competencia), Datas.mes(calculo.competencia), calculo.quantidadeDiasCompetencia)
int idade = Funcoes.idade(servidor.dataNascimento, finalCpt);
if (idade < 65) {
    suspender 'O evento não é calculado para pessoas com idade menor que 65 anos'
}
parcelaIsenta = Bases.valor(Bases.IRRF) + Eventos.valor(138) + Eventos.valor(50) + Eventos.valor(52) + Eventos.valor(54) + Eventos.valor(56) + Eventos.valor(243)
primeiraFaixaIrrf = EncargosSociais.IRRF.buscaContribuicao(0, 1) //retorna o valor da menor faixa de IRRF
if (parcelaIsenta > primeiraFaixaIrrf) {
    parcelaIsenta = primeiraFaixaIrrf
}
parcelaIsenta -= Eventos.valor(192)
valorCalculado = parcelaIsenta
