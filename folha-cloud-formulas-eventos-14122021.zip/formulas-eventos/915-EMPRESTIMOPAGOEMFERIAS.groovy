if (calculo.replicaEventosCalculoFeriasParaCalculoMensal) {
    double vaux = Lancamentos.valor(evento)
    if (vaux > 0) {
        valorCalculado = vaux
    } else {
        if (!TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && !TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento)) {
            suspender \"O evento deve ser calculado apenas em processamentos mensais ou rescisórios\"
        }
        if (SubTipoProcessamento.ADIANTAMENTO.equals(calculo.subTipoProcessamento)) {
            suspender \"O evento não é calculado no subtipo de processamento 'adiantamento'\"
        }
        valorCalculado = Eventos.valorCalculado(119, TipoValor.CALCULADO, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL)
    }
    if (valorCalculado > 0) {
        evento.replicado(true)
    }
}
