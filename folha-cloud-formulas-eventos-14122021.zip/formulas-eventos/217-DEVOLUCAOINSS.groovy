//Este evento deve ser configurado para calcular por último (Guia Geral > Calcular por último)
if (!TipoMatricula.FUNCIONARIO.equals(matricula.tipo) && !TipoMatricula.AUTONOMO.equals(matricula.tipo)) {
    suspender \"Este cálculo é executado apenas para funcionários ou autônomos\"
}
if (Funcoes.possuiPrevidenciaFederal(matricula.tipo)) {
    if (!TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && !TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento)) {
        suspender \"O evento deve ser calculado apenas em processamentos mensais ou rescisórios\"
    }
    //soma a base de INSS com a base que está sendo calculada
    def baseprev = Bases.valor(Bases.INSS) + Bases.valor(Bases.INSSFER) + Bases.valor(Bases.INSSOUTRA) + Bases.valorCalculado(Bases.INSSOUTRA, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL)
    if (baseprev <= 0 && SubTipoProcessamento.INTEGRAL.equals(calculo.subTipoProcessamento)) {
        suspender \"Não há valor de base de I.N.S.S., I.N.S.S. férias ou I.N.S.S. de outras empresas para cálculo\"
    }
    double valorInssAnterior = 0
    if (SubTipoProcessamento.COMPLEMENTAR.equals(calculo.subTipoProcessamento)) {
        //busca o valor de INSS calculada na mensal e complementar anterior
        double baseInssMensalIntegral = Bases.valorCalculado(Bases.INSS, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL)
        double baseInssFerMensalIntegral = Bases.valorCalculado(Bases.INSSFER, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL)
        double baseInssRescisaoIntegral = Bases.valorCalculado(Bases.INSS, TipoProcessamento.RESCISAO, SubTipoProcessamento.INTEGRAL)
        double baseInssOutrasEmpresasEmFerias = Bases.valorCalculado(Bases.INSSOUTRA, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL)
        double baseInss = baseInssMensalIntegral + baseInssFerMensalIntegral + baseInssRescisaoIntegral + baseInssOutrasEmpresasEmFerias
        if (baseInss > 0) {
            double valorInssMensalIntegralAnterior = Eventos.valorCalculado(ClassificacaoEvento.INSS, TipoValor.CALCULADO, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL, calculo.competencia)
            double valorInssMensalComplementarAnterior = Eventos.valorCalculado(ClassificacaoEvento.INSS, TipoValor.CALCULADO, TipoProcessamento.MENSAL, SubTipoProcessamento.COMPLEMENTAR, calculo.competencia)
            double valorDevolucaoInssMensalIntegralAnterior = Eventos.valorCalculado(ClassificacaoEvento.DEVINSS, TipoValor.CALCULADO, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL, calculo.competencia)
            double valorDevolucaoInssMensalComplementarAnterior = Eventos.valorCalculado(ClassificacaoEvento.DEVINSS, TipoValor.CALCULADO, TipoProcessamento.MENSAL, SubTipoProcessamento.COMPLEMENTAR, calculo.competencia)
            double valorInssMensalAnterior = valorInssMensalIntegralAnterior + valorInssMensalComplementarAnterior
            double valorDevolucaoInssMensalAnterior = valorDevolucaoInssMensalIntegralAnterior + valorDevolucaoInssMensalComplementarAnterior
            valorInssAnterior += valorInssMensalAnterior - valorDevolucaoInssMensalAnterior
        }
    }
    def max = EncargosSociais.RGPS.buscaMaior(1)
    def vaux = baseprev
    if (vaux > max) {
        vaux = max
    }
    if (TipoMatricula.FUNCIONARIO.equals(matricula.tipo)) {
        vaux2 = Numeros.trunca(vaux, 2)
        if (funcionario.conselheiroTutelar) {
            valorReferencia = 11
        } else {
            valorReferencia = EncargosSociais.RGPS.buscaContribuicao(vaux2, 2)
        }
    } else {
        if (EncargosSociaisFpas.ENTIDADE_BENEFICENTE.equals(EncargosSociais.RGPS.codigoFpas) && (TipoMatricula.AUTONOMO.equals(matricula.tipo))) {
            valorReferencia = 20
        } else {
            valorReferencia = EncargosSociais.RGPS.buscaMaior(2)
            if (TipoMatricula.AUTONOMO.equals(matricula.tipo)) {
                valorReferencia = 11
            }
        }
    }
    if (Funcoes.inicioCompetencia() >= Datas.data(2020, 3, 1) && !TipoMatricula.AUTONOMO.equals(matricula.tipo) && !funcionario.conselheiroTutelar) {
        vaux = Funcoes.calculoProgressivoINSS(vaux)
    } else {
        vaux = (vaux * valorReferencia) / 100
    }
    double inssValorAtual = Numeros.trunca(vaux, 2)
    if ((valorInssAnterior > inssValorAtual) && (valorInssAnterior > 0)) {
        valorCalculado = valorInssAnterior - inssValorAtual
    }
}
