def vaux = Lancamentos.valor(evento)
if (vaux > 0) {
    valorReferencia = vaux
} else {
    def cedidocomonus = Funcoes.cedidocomonus()
    if (cedidocomonus <= 0) {
        suspender \"Não há afastamento com a classificação 'Cedência', com ônus, na competência\"
    }
    vaux = Funcoes.cnvdpbase(cedidocomonus)
    valorReferencia = vaux
}
double remuneracao = Funcoes.calcprop(Funcoes.remuneracao(matricula.tipo).valor, vaux)
if (remuneracao > 0) {
    valorCalculado = remuneracao
}
