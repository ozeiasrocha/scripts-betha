if (!TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
    suspender \"O evento deve ser calculado apenas em processamentos mensais\"
}
Funcoes.somenteFuncionarios()
if (funcionario.possuiPrevidencia(TipoPrevidencia.ASSISTENCIA_MUNICIPAL)) {
    double valorAbatimento
    double vaux = Lancamentos.valor(evento)
    if (vaux > 0) {
        valorAbatimento = vaux
    } else {
        def valorFundoAssistFeriasIntegral = Funcoes.getValorCodigoEventoFerias(90, true).valor
        if (valorFundoAssistFeriasIntegral > 0) {
            valorAbatimento = Eventos.valor(906)
        }
    }
    if (valorAbatimento > 0) {
        valorCalculado = valorAbatimento
        evento.replicado(true)
    }
}
