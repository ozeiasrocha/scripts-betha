boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
double desc = 0
double vaux2 = 0
vaux = Lancamentos.valor(evento)
if (vaux >= 0) {
    valorCalculado = vaux
    vaux2 = Numeros.trunca(vaux, 2)
    desc = EncargosSociais.IRRF.buscaContribuicao(vaux2, 3)
} else {
    def baseOutrosVinculos = Funcoes.getValorBaseMultiplosVinculos(Bases.IRRF13, calculo.tipoProcessamento, calculo.subTipoProcessamento)
    def irrfOutrosVinculos = 0
    if (baseOutrosVinculos > 0) {
        irrfOutrosVinculos = Eventos.valorCalculadoMultiplosVinculos(ClassificacaoEvento.IRRF13SAL, TipoValor.CALCULADO, calculo.tipoProcessamento, calculo.subTipoProcessamento)
        if (TipoProcessamento.DECIMO_TERCEIRO_SALARIO.equals(calculo.tipoProcessamento) && SubTipoProcessamento.INTEGRAL.equals(calculo.subTipoProcessamento)) {
            irrfOutrosVinculos += Eventos.valorCalculadoMultiplosVinculos(ClassificacaoEvento.IRRF13SAL, TipoValor.CALCULADO, TipoProcessamento.RESCISAO, SubTipoProcessamento.INTEGRAL)
        }
        if (TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento) && SubTipoProcessamento.INTEGRAL.equals(calculo.subTipoProcessamento)) {
            irrfOutrosVinculos += Eventos.valorCalculadoMultiplosVinculos(ClassificacaoEvento.IRRF13SAL, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL)
        }
    }
    double base = Bases.valor(Bases.IRRF13) - Eventos.valor(136) - Eventos.valor(190) - Eventos.valor(193) + Bases.valor(Bases.IRRFOUTRA13) + baseOutrosVinculos + Eventos.valor(200)
    valorCalculado = 0
    if (base >= EncargosSociais.IRRF.buscaContribuicao(0, 1)) {
        vaux2 = Numeros.trunca(base, 2)
        desc = EncargosSociais.IRRF.buscaContribuicao(vaux2, 3)
        valorReferencia = EncargosSociais.IRRF.buscaContribuicao(vaux2, 2)
        valorCalculado = ((vaux2 * valorReferencia) / 100) - desc - irrfOutrosVinculos - Eventos.valor(173)
    }
}
if (valorCalculado < EncargosSociais.IRRF.minimoIrrfDarf) {
    valorCalculado = 0
} else {
    Bases.compor(desc, Bases.DESCIRRF13)
}
