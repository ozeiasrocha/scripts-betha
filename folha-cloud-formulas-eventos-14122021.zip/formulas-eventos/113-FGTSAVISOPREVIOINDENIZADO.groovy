Funcoes.somenteFuncionarios()
def optanteFgts = Funcoes.optanteFgts(matricula.tipo)
if (!optanteFgts) {
    suspender \"A matrícula não é optante de FGTS\"
}
def avisoinden = Funcoes.avisoPrevioIndenizado()
if (!avisoinden) {
    suspender 'Não há aviso prévio a ser indenizado ao funcionário'
}
def vaux = Lancamentos.valor(evento)
if (vaux > 0) {
    valorCalculado = vaux
} else {
    if (funcionario.categoriaSefipVinculo.toString() == 'MENOR_APRENDIZ') {
        valorReferencia = 2
    } else {
        valorReferencia = evento.taxa
    }
    vaux = Bases.valor(Bases.FGTSAVISO) * valorReferencia / 100
    valorCalculado = Numeros.arredonda(vaux, 2)
}
