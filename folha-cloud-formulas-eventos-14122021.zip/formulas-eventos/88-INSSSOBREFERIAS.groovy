Funcoes.somenteFuncionarios()
if (!TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento)) {
  suspender \"O evento deve ser calculado apenas em processamentos de férias\"
}
if (funcionario.possuiPrevidenciaFederal) {
  if (folha.folhaPagamento) {
    def vaux = Lancamentos.valor(evento)
    if (vaux > 0) {
      valorReferencia = vaux
      valorCalculado = vaux
    } else {
      def baseOutrosVinculos = Funcoes.getValorBaseMultiplosVinculos(Bases.INSSFER, calculo.tipoProcessamento, calculo.subTipoProcessamento)
      def inssOutrosVinculos = 0
      if (baseOutrosVinculos > 0) {
        inssOutrosVinculos = Eventos.valorCalculadoMultiplosVinculos(evento.codigo, TipoValor.CALCULADO, calculo.tipoProcessamento, calculo.subTipoProcessamento)
      }
      def baseprev = Bases.valor(Bases.INSSFER) + baseOutrosVinculos + Bases.valor(Bases.INSSOUTRA) + Bases.valorCalculado(Bases.INSSFER, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL) + Bases.valorCalculado(Bases.INSSOUTRA, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL)
      if (baseprev <= 0) {
        suspender \"Não há valor de base de I.N.S.S. ou I.N.S.S. de outras empresas para cálculo\"
      } else {
        def max = EncargosSociais.RGPS.buscaMaior(1)
        if (baseprev > max) {
          vaux = max
        } else {
          vaux = baseprev
        }
        def base = vaux
        vaux2 = Numeros.trunca(vaux, 2)
        if (funcionario.conselheiroTutelar) {
          valorReferencia = 11
        } else {
          valorReferencia = EncargosSociais.RGPS.buscaContribuicao(vaux2, 2)
        }
        if (Funcoes.inicioCompetencia() >= Datas.data(2020, 3, 1) && !funcionario.conselheiroTutelar) {
          vaux = Funcoes.calculoProgressivoINSS(base)
          valorCalculado = Numeros.arredonda(vaux, 2) - inssOutrosVinculos - Eventos.valorCalculado(evento.codigo, TipoValor.CALCULADO, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL) - Eventos.valor(169)
        } else {
          vaux = (base * valorReferencia) / 100
          valorCalculado = Numeros.trunca(vaux, 2) - inssOutrosVinculos - Eventos.valorCalculado(evento.codigo, TipoValor.CALCULADO, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL) - Eventos.valor(169)
        }
      }
    }
    Bases.compor(valorCalculado, Bases.IRRFFER, Bases.ABATIRRF)
  }
}
