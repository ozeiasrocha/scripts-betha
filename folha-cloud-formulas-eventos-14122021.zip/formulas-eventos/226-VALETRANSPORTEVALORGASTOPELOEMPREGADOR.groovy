Funcoes.somenteFuncionarios()
if (TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento)) {
    suspender \"O evento não deve ser calculado em processamentos de férias\"
}
if (Bases.valor(Bases.PAGAPROP) == 0) {
    suspender \"Não é possível calcular o vale transporte para funcionários sem valor de base 'Paga proporcional'\"
}
def vaux = Lancamentos.valor(evento)
if (vaux >= 0) {
    valorReferencia = vaux
    valorCalculado = vaux
} else {
    vaux = ValesTransporte.busca(TipoRetornoValeTransporte.VALOR)
    if (vaux <= 0) {
        suspender \"Não há valores de vale transporte a serem pagos para o funcionário na competência\"
    }
    valorReferencia = ValesTransporte.busca(TipoRetornoValeTransporte.QUANTIDADE)
    valorCalculado = vaux
}
