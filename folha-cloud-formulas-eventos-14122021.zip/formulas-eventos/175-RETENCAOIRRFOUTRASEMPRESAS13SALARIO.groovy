Funcoes.somenteFuncionarios()
def vaux = Lancamentos.valor(evento);
if (vaux <= 0) {
    boolean mesDemissao
    def dataRescisao = calculo.dataRescisao
    if (dataRescisao != null) {
        if (Datas.ano(dataRescisao) == Datas.ano(calculo.competencia) && Datas.mes(dataRescisao) == Datas.mes(calculo.competencia) && calculo.quantidadeDiasCompetencia >= Datas.dia(dataRescisao)) {
            mesDemissao = true
        }
    }
    if (mesDemissao) {
        vaux = BasesOutrasEmpresas.buscaPor(TipoProcessamento.DECIMO_TERCEIRO_SALARIO).sum(0, { it.valorRetidoIrrf })
    } else {
        vaux = BasesOutrasEmpresas.buscaPor(calculo.tipoProcessamento).sum(0, { it.valorRetidoIrrf })
    }
}
if (vaux <= 0){
    suspender \"Não é possível calcular a retenção I.R.R.F. de outras empresas em décimo terceiro para funcionários que na competência não tenham o valor lançado para o cálculo ou que não tenham valor de base 'Paga proporcional'\"
}
valorCalculado = vaux
valorCalculado = vaux
