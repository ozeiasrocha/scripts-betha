Funcoes.somenteFuncionarios()
if (TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento)) {
    suspender \"O evento não deve ser calculado em processamentos de férias\"
}
def vlrcalcfgts = 0
def vaux = Lancamentos.valor(evento)
if (vaux > 0) {
    vlrcalcfgts = vaux
} else {
    def funcaoGratificada = 0
    funcaoGratificada = FuncoesGratificadas.busca(0) //inserir id da função
    def salario = Funcoes.remuneracao(matricula.tipo).valor
    vaux = salario * evento.taxa / 100
    vaux = Funcoes.calcprop(vaux, Funcoes.cnvdpbase(funcaoGratificada))
    def dias = Funcoes.diastrab() + Funcoes.afasdirinteg() + Funcoes.afaslicmat() + Funcoes.afasprorroglicmat() + Funcoes.afasaborto() + Funcoes.afasadocao() + Funcoes.afasprorroglicmatlei11770() + Funcoes.cedidosemonus() + Funcoes.afasacidtrab() + Funcoes.afasservmil()
    vlrcalcfgts = Funcoes.calcprop(vaux, Funcoes.cnvdpbase(dias))
}
valorReferencia = vaux
valorCalculado = vaux
Bases.compor(valorCalculado,
        Bases.SALBASE,
        Bases.IRRF,
        Bases.INSS,
        Bases.FUNDOPREV,
        Bases.FUNDASS,
        Bases.PREVEST,
        Bases.SALAFAM,
        Bases.MEDIAUXMAT,
        Bases.FUNDFIN)
Bases.compor(vlrcalcfgts, Bases.FGTS)
