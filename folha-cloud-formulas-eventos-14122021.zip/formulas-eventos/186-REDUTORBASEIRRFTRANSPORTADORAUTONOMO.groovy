if (!TipoMatricula.AUTONOMO.equals(matricula.tipo) || (autonomo.descricaoOrganograma =~ /AUTÔNOMO.*TRANSPORTE/).size() == 0) {
    suspender 'Este cálculo é executado apenas para autônomos transportadores de passageiros/cargas'
}
def vvar = Lancamentos.valor(evento);
if (vvar > 0) {
    valorCalculado = vvar;
    valorReferencia = vvar;
} else {
    def aliquota = 0
    valorCalculado = 0
    if ((autonomo.descricaoOrganograma =~ /AUTÔNOMO.*TRANSPORTE.*CARGA/).size() > 0) {
        aliquota = 0.9
    } else {
        aliquota = 0.4
    }
    valorCalculado = autonomo.totalServicosAutonomo * aliquota
}
if (valorCalculado > 0) {
    Bases.compor(valorCalculado, Bases.IRRF)
}
