if (!TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
    suspender \"O evento deve ser calculado apenas em processamentos mensais\"
}
Funcoes.somenteFuncionarios()
if (funcionario.possuiPrevidencia(TipoPrevidencia.PREVIDENCIA_PROPRIA)) {
    double valorAbatimento
    double vaux = Lancamentos.valor(evento)
    if (vaux > 0) {
        valorAbatimento = vaux
    } else {
        def valorFundoPrevFeriasIntegral = Funcoes.getValorCodigoEventoFerias(91, true).valor
        if (valorFundoPrevFeriasIntegral > 0) {
            valorAbatimento = Eventos.valor(907)
        }
    }
    if (valorAbatimento > 0) {
        valorCalculado = valorAbatimento
        evento.replicado(true)
    }
}
