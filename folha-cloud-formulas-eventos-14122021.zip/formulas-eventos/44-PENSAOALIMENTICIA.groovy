if (!Funcoes.pagapensao()) {
    suspender \"O servidor não possui dependentes pensão\"
}
def vvar = Lancamentos.valor(evento);
if (vvar > 0) {
    valorReferencia = vvar
    valorCalculado = vvar
} else {
    if (Eventos.valorCalculado(evento.codigo, TipoValor.CALCULADO, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL) > 0 && TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
        suspender \"O evento já foi calculado em processamento de férias\"
    }
    def salario = Funcoes.remuneracao(matricula.tipo).valor;
    double valorTotalPensao
    def quantidadePensionistas = servidor.buscaDependentes.sum(0, { it.pensao ? 1 : 0 })
    def valorPensaoPorDependente
    servidor.buscaDependentes.each { dependente ->
        if (dependente.pensao) {
            if (dependente.aplicacaoDesconto.toString().equals('VALOR_PERCENTUAL')) {
                valorPensaoPorDependente = (salario * dependente.percentualDesconto / 100) / quantidadePensionistas
            } else {
                valorPensaoPorDependente = dependente.valorDesconto
            }
            valorPensaoPorDependente = Numeros.arredonda(valorPensaoPorDependente,2)
            dependente.aplicaRateio(valorPensaoPorDependente)
            valorTotalPensao += valorPensaoPorDependente
        }
    }
    valorCalculado = valorTotalPensao
}
Bases.compor(valorCalculado, Bases.IRRF)
