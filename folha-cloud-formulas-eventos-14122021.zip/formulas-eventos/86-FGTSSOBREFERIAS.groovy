Funcoes.somenteFuncionarios()
def optanteFgts = Funcoes.optanteFgts(matricula.tipo)
if (!optanteFgts) {
    suspender \"A matrícula não é optante de FGTS\"
}
if (!TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento)) {
    suspender \"O evento deve ser calculado apenas em processamentos de férias\"
}
if (folha.folhaPagamento) {
    def vaux = Lancamentos.valor(evento)
    if (vaux >= 0) {
        valorCalculado = vaux
    } else {
        double basefer = Bases.valorCalculado(Bases.FGTS, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL)
        double fgtsfer; double fgts13a; double fgts13i; double base13a; double base13i;
        if (basefer > 0) {
            fgtsfer = Eventos.valorCalculado(evento.codigo, TipoValor.CALCULADO, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL)
        }
        if (Funcoes.diasferias() >= 30) {
            base13a = Bases.valorCalculado(Bases.FGTS13, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.ADIANTAMENTO)
            base13i = Bases.valorCalculado(Bases.FGTS13, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL)
            if (base13a > 0 || base13i > 0) {
                fgts13a = Eventos.valorCalculado(37, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.ADIANTAMENTO)
                fgts13i = Eventos.valorCalculado(37, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL)
            }
        }
        double base = Bases.valor(Bases.FGTS) + basefer + base13a + base13i
        valorReferencia = evento.taxa
        vaux = base * valorReferencia / 100
        vaux = vaux - fgtsfer - fgts13a - fgts13i
        valorCalculado = vaux.trunc(2)
    }
}
