if (!TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
    suspender \"O evento deve ser calculado apenas em processamentos mensais\"
}
Funcoes.somenteFuncionarios()
if (funcionario.possuiPrevidenciaFederal) {
    double valorAbatimento
    double vaux = Lancamentos.valor(evento)
    if (vaux > 0) {
        valorAbatimento = vaux
    } else {
        def valorInssFeriasIntegral = Funcoes.getValorCodigoEventoFerias(88, true).valor
        if (valorInssFeriasIntegral > 0) {
            valorAbatimento = Eventos.valor(902)
        }
    }
    if (valorAbatimento > 0) {
        valorCalculado = valorAbatimento
        evento.replicado(true)
    }
}
