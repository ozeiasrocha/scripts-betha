Funcoes.somenteFuncionarios()
def vaux = Lancamentos.valor(evento)
if (vaux >= 0) {
    valorReferencia = vaux
} else {
    def afaslicsvenc = Funcoes.afaslicsvenc()
    if (afaslicsvenc <= 0) {
        suspender \"Não há afastamento com a classificação 'Licença SEM vencimentos' na competência\"
    }
    vaux = Funcoes.cnvdpbase(afaslicsvenc)
    valorReferencia = vaux
}
double remuneracao = Funcoes.calcprop(funcionario.salario, vaux)
if (remuneracao > 0) {
    valorCalculado = remuneracao
}
