Funcoes.somenteFuncionarios()
def optanteFgts = Funcoes.optanteFgts(matricula.tipo)
if (!optanteFgts) {
    suspender \"A matrícula não é optante de FGTS\"
}
if (!(TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && SubTipoProcessamento.INTEGRAL.equals(calculo.subTipoProcessamento)) ||
        !(TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento) && SubTipoProcessamento.INTEGRAL.equals(calculo.subTipoProcessamento))) {
    suspender \"O evento deve ser calculado apenas nos processamentos mensal (integral) ou rescisão (integral)\"
}
def basefgtsFerias = Bases.valorCalculado(Bases.FGTS, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL)
if (basefgtsFerias <= 0) {
    suspender \"Não há valor de base de FGTS nas férias para cálculo\"
}
def fgtsFeriasAnteriores = Eventos.valorCalculado(86, TipoValor.CALCULADO, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL)
def basefgts = basefgtsFerias + Bases.valor(Bases.FGTS)
if (funcionario.categoriaSefipVinculo.toString() == 'MENOR_APRENDIZ') {
    valorReferencia = 2
} else {
    valorReferencia = evento.taxa
}
def vaux = basefgts * valorReferencia / 100
def fgtsFeriasAtual = Numeros.trunca(vaux,2)
if ((fgtsFeriasAnteriores > fgtsFeriasAtual) && (fgtsFeriasAnteriores > 0)) {
    valorCalculado = fgtsFeriasAnteriores - fgtsFeriasAtual
}
