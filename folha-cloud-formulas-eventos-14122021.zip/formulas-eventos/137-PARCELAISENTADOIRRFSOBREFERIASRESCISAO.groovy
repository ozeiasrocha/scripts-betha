suspender 'Este evento foi descontinuado. Devido atualização da legislação, este evento não se faz mais necessário'
