Funcoes.somenteFuncionarios()
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
if (funcionario.possuiPrevidenciaFederal) {
    def baseOutrosVinculos = Funcoes.getValorBaseMultiplosVinculos(Bases.INSS13, calculo.tipoProcessamento, calculo.subTipoProcessamento)
    def baseInssComOutrasEmpresas = Bases.valor(Bases.INSS13) + Bases.valor(Bases.INSSOUTRA13) + baseOutrosVinculos + Eventos.valor(200)
    def inssOutrosVinculos = 0
    if (baseOutrosVinculos > 0) {
        inssOutrosVinculos = Eventos.valorCalculadoMultiplosVinculos(ClassificacaoEvento.INSS13SAL, TipoValor.CALCULADO, calculo.tipoProcessamento, calculo.subTipoProcessamento)
        if (TipoProcessamento.DECIMO_TERCEIRO_SALARIO.equals(calculo.tipoProcessamento) && SubTipoProcessamento.INTEGRAL.equals(calculo.subTipoProcessamento)) {
            inssOutrosVinculos += Eventos.valorCalculadoMultiplosVinculos(ClassificacaoEvento.INSS13SAL, TipoValor.CALCULADO, TipoProcessamento.RESCISAO, SubTipoProcessamento.INTEGRAL)
        }
        if (TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento) && SubTipoProcessamento.INTEGRAL.equals(calculo.subTipoProcessamento)) {
            inssOutrosVinculos += Eventos.valorCalculadoMultiplosVinculos(ClassificacaoEvento.INSS13SAL, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL)
        }
    }
    if (TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
        baseInssComOutrasEmpresas =
                baseInssComOutrasEmpresas +
                        Bases.valorCalculado(Bases.INSS13, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL) +
                        Bases.valorCalculado(Bases.INSSOUTRA13, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL) +
                        Eventos.valorCalculado(200, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL)
    }
    if (baseInssComOutrasEmpresas == 0) {
        suspender 'Não há valor de base de INSS décimo terceiro para cálculo'
    }
    def vaux = Lancamentos.valor(evento)
    if (vaux >= 0) {
        valorReferencia = vaux
        valorCalculado = vaux
    } else {
        def excedenteInss = 0
        def tetoInss = EncargosSociais.RGPS.buscaMaior(1)
        if (baseInssComOutrasEmpresas > tetoInss) {
            excedenteInss = baseInssComOutrasEmpresas - tetoInss
            baseInssComOutrasEmpresas = tetoInss
        }
        if (funcionario.conselheiroTutelar) {
            valorReferencia = 11
        } else {
            valorReferencia = EncargosSociais.RGPS.buscaContribuicao(baseInssComOutrasEmpresas, 2)
        }
        def baseFolha13 = 0
        def somaBaseFolha13FolhaAtual = baseFolha13 + baseInssComOutrasEmpresas
        if (somaBaseFolha13FolhaAtual > tetoInss) {
            baseInssComOutrasEmpresas = (tetoInss - baseFolha13)
        }
        if (Funcoes.inicioCompetencia() >= Datas.data(2020, 3, 1) && !funcionario.conselheiroTutelar) {
            vaux = Funcoes.calculoProgressivoINSS(baseInssComOutrasEmpresas)
            valorCalculado = Numeros.arredonda(vaux, 2) - inssOutrosVinculos - Eventos.valor(171)
        } else {
            vaux = baseInssComOutrasEmpresas * valorReferencia / 100
            valorCalculado = Numeros.trunca(vaux, 2) - inssOutrosVinculos - Eventos.valor(171)
        }
        if (TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
            valorCalculado = valorCalculado - Eventos.valorCalculado(evento.codigo, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL)
        }
        Bases.compor(excedenteInss, Bases.EXCEINSS)
    }
    Bases.compor(valorCalculado, Bases.IRRF13, Bases.ABATIRRF13)
}
