suspender \"Este evento foi descontinuado. O evento 163 calculará os afastamentos com classificação 'Adoção/guarda judicial de criança'\"
