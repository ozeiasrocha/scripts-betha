suspender 'Este evento foi descontinuado. Os recessos por padrão serão pagos somente em uma competência'
