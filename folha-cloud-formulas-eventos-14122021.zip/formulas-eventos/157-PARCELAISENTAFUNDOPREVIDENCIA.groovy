Funcoes.somenteAposentadosPensionistas()
if (!Funcoes.possuiPrevidencia(TipoPrevidencia.PREVIDENCIA_PROPRIA)) {
    suspender \"Este cálculo é realizado apenas para funcionários contribuintes da previdência própria\"
}
def vaux = EncargosSociais.IRRF.buscaContribuicao(0, 1)
def vbase = Bases.valor(Bases.FUNDOPREV)
if (vbase < vaux) {
    vaux = vbase
}
valorCalculado = vaux
