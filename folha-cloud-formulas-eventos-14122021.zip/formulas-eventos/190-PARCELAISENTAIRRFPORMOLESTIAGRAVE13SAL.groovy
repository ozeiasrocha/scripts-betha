Funcoes.somenteAposentadosPensionistas()
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
if (!servidor.possuiMolestiaGrave) {
    suspender 'O evento deve ser calculado apenas para pessoas que possuam moléstia grave'
}
def parcelaIsenta = Bases.valor(Bases.PAISIR13SA)
if (parcelaIsenta > 0) {
    valorCalculado = parcelaIsenta
}
