Funcoes.somenteAposentadosPensionistas()
if (!servidor.possuiMolestiaGrave) {
    suspender 'O evento deve ser calculado apenas para pessoas que possuam moléstia grave'
}
double parcelaIsenta = Bases.valor(Bases.PARCISENIRRF)
if (parcelaIsenta > 0) {
    valorCalculado = parcelaIsenta
}
