if (!TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
    suspender \"O evento deve ser calculado apenas em processamentos mensais\"
}
Funcoes.somenteFuncionarios()
if (funcionario.possuiPrevidencia(TipoPrevidencia.FUNDO_FINANCEIRO)) {
    double valorAbatimento
    double vaux = Lancamentos.valor(evento)
    if (vaux > 0) {
        valorAbatimento = vaux
    } else {
        def valorFundoFinancFeriasIntegral = Funcoes.getValorCodigoEventoFerias(249, true).valor
        if (valorFundoFinancFeriasIntegral > 0) {
            valorAbatimento = Eventos.valor(908)
        }
    }
    if (valorAbatimento > 0) {
        valorCalculado = valorAbatimento
        evento.replicado(true)
    }
}
