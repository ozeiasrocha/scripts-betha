if (!TipoMatricula.APOSENTADO.equals(matricula.tipo) || !TipoMatricula.PENSIONISTA.equals(matricula.tipo)) {
    suspender \"Este cálculo é executado apenas para aposentados ou pensionistas\"
}
if (!Funcoes.possuiPrevidencia(TipoPrevidencia.FUNDO_FINANCEIRO)) {
    suspender \"Este cálculo é realizado apenas para funcionários contribuintes do fundo financeiro\"
}
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
def vaux = EncargosSociais.IRRF.buscaContribuicao(0, 1)
def vbase = Bases.valor(Bases.FUNDFIN13)
if (vbase < vaux) {
    vaux = vbase
}
valorCalculado = vaux
