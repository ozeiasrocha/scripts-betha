//Este evento demonstra na folha mensal o valor calculado de IRRF de férias de forma proporcional, conforme os dias de férias em cada competência, quando o parâmetro 'Replicar eventos do cálculo de férias para o cálculo mensal' está ativo
if (!TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
    suspender \"O evento deve ser calculado apenas em processamentos mensais\"
}
if (!TipoMatricula.FUNCIONARIO.equals(matricula.tipo) && !TipoMatricula.ESTAGIARIO.equals(matricula.tipo)) {
    suspender \"Este cálculo é executado apenas para funcionários e estagiários\"
}
double vaux = Lancamentos.valor(evento)
if (vaux > 0) {
    valorCalculado = vaux
} else {
    irrfFerias = Funcoes.getIrrfFerias()
    valorReferencia = irrfFerias.referencia
    valorCalculado = irrfFerias.valor
}
if (valorCalculado > 0) {
    evento.replicado(true)
}
