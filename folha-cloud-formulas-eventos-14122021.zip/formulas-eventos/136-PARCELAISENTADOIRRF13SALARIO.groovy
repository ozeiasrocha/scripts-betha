Funcoes.somenteAposentadosPensionistas()
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
if (servidor.possuiMolestiaGrave) {
    suspender 'O evento não é calculado para pessoas que possuam moléstia grave'
}
if (!servidor.dataNascimento) {
    suspender 'O evento não é calculado para pessoas que não tenham data de nascimento informada'
}
def finalCpt = Datas.data(Datas.ano(calculo.competencia), Datas.mes(calculo.competencia), calculo.quantidadeDiasCompetencia)
int idade = Funcoes.idade(servidor.dataNascimento, finalCpt)
if (idade < 65) {
    suspender 'O evento não é calculado para pessoas com idade menor que 65 anos'
}
def parcelaIsenta = Bases.valor(Bases.IRRF13)
def primeiraFaixaIrrf = EncargosSociais.IRRF.buscaContribuicao(0, 1) //retorna o valor da menor faixa de IRRF
if (parcelaIsenta > primeiraFaixaIrrf) {
    parcelaIsenta = primeiraFaixaIrrf
}
parcelaIsenta -= Eventos.valor(193)
valorCalculado = parcelaIsenta
