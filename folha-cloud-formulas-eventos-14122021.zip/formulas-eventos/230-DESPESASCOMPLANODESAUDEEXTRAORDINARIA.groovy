def ferias = Funcoes.replicaEventoVariavel(evento.codigo)
def vvar = Lancamentos.valor(evento)
if (vvar > 0) {
    if (ferias.valor > 0) {
        double diferenca = vvar - ferias.valor
        if (diferenca > 0) {
            valorCalculado = ferias.valor + diferenca
        } else {
            valorCalculado = ferias.valor
        }
        valorReferencia = valorCalculado
    } else {
        if (TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento) || TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento)) {
            double vlrCalc = vvar - Eventos.valorCalculado(evento.codigo, TipoValor.CALCULADO, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL)
            if (vlrCalc > 0) {
                valorReferencia = vlrCalc
                valorCalculado = vlrCalc
            }
        } else {
            valorReferencia = vvar
            valorCalculado = vvar
        }
    }
}
