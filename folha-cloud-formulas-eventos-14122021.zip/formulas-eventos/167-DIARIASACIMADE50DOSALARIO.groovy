Funcoes.somenteFuncionarios()
if (Datas.data(calculo.competencia.ano, calculo.competencia.mes, 1) <= Datas.data(2017, 11, 1)) {
    if (TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
        def vvar = Lancamentos.valor(evento)
        if (vvar > 0) {
            valorReferencia = vvar
            valorCalculado = vvar
            Bases.compor(valorCalculado,
                    Bases.FGTS,
                    Bases.INSS,
                    Bases.PREVEST,
                    Bases.FUNDOPREV,
                    Bases.FUNDFIN,
                    Bases.MEDIAUXMAT)
        }
    }
}
