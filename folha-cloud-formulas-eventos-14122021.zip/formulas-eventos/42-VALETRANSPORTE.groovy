Funcoes.somenteFuncionarios()
if (TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento)) {
    suspender \"O evento não deve ser calculado em processamentos de férias\"
}
if (Bases.valor(Bases.PAGAPROP) == 0) {
    suspender \"Não é possível calcular o vale transporte para funcionários sem valor de base 'Paga proporcional'\"
}
valorReferencia = evento.taxa
def vaux = Lancamentos.valor(evento)
if (vaux <= 0) {
    vaux = ValesTransporte.busca(TipoRetornoValeTransporte.VALOR)
    if (vaux <= 0) {
        suspender \"Não há valores de vale transporte a serem pagos para o funcionário na competência\"
    }
}
if (vaux > 0) {
    def maxdesc = Funcoes.remuneracao(matricula.tipo).valor * evento.taxa / 100
    if (vaux <= maxdesc) {
        valorCalculado = vaux
    } else {
        valorCalculado = maxdesc
    }
}
