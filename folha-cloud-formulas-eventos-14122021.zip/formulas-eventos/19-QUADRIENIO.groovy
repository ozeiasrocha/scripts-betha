Funcoes.somenteFuncionarios()
if (TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento)) {
    suspender \"O evento não deve ser calculado em processamentos de férias\"
}
int forma = 1 //1-Normal , 2-Composto
boolean somenteFgts = false
def valBaseFgts = 0
int rh = 0
int novant = 0
int meses = 0
def cptproc = Datas.data(Datas.ano(calculo.competencia), Datas.mes(calculo.competencia), 1)
def dtbase = funcionario.dataBase
if (dtbase == null) {
    dtbase = funcionario.dataAdmissao
}
def vvar = Lancamentos.valor(evento)
def vvarFgts = Lancamentos.valor(evento)
if (vvar < 0 || vvarFgts < 0) {
    novant = AdicionaisTempoServico.busca(TipoAdicional.QUANTIDADE_ADICIONAIS, ClassificacaoAdicional.QUADRIENIO)
    rh = 1
} else {
    if (vvar < 0) {
        somenteFgts = true
    }
    def dfin = Datas.data(calculo.competencia.ano, calculo.competencia.mes, calculo.quantidadeDiasCompetencia)
    // Inicia o período de calamidade
    def cptInicial = dtbase
    def cptFinal = calculo.competencia
    if (Datas.formatar(cptInicial, \"yyyyMM\").toInteger() < 202005) {
        cptInicial = Datas.data(2020,5,1)
    }
    if (Datas.formatar(cptFinal, \"yyyyMM\").toInteger() > 202112) {
        cptFinal = Datas.data(2021,12,31)
    }
    def afastamentos = [ClassificacaoTipoAfastamento.AUXILIO_DOENCA_PREVIDENCIA, ClassificacaoTipoAfastamento.LICENCA_SEM_VENCIMENTOS]
    if (cptFinal >= cptInicial) {
        // O período de calamidade deve desconsiderar os afastamentos existentes dentro do período
        meses = Datas.diferencaMeses(cptInicial, cptFinal) + 1
        cptInicial = Datas.removeMeses(cptInicial, 1)
        cptInicial = Datas.data(Datas.ano(cptInicial), Datas.mes(cptInicial), calculo.quantidadeDias(Datas.mes(cptInicial), Datas.ano(cptInicial)))
        cptFinal = Datas.adicionaMeses(cptFinal, 1)
        cptFinal = Datas.data(Datas.ano(cptFinal), Datas.mes(cptFinal), 1)
        // Afastamentos anteriores ao período de calamidade
        meses += Funcoes.mesesafast(dtbase, cptInicial, afastamentos)
        // Afastamentos poteriores ao período de calamidade
        meses += Funcoes.mesesafast(cptFinal, dfin, afastamentos)
    } else {
        meses += Funcoes.mesesafast(dtbase, dfin, afastamentos)
    }
    // Finaliza o período de calamidade
    if (meses > 0) {
        dfin = Datas.removeMeses(cptproc, meses)
        int dia = calculo.quantidadeDias(Datas.mes(dfin), Datas.ano(dfin))
        if (Datas.mes(dfin).equals(2)) {
            if (Datas.ano(dfin)) {
                if (Numeros.resto(Datas.ano(dfin), 4) == 0) {
                    dia = 29
                } else {
                    dia = 28
                }
            }
        }
        dfin = Datas.data(Datas.ano(dfin), Datas.mes(dfin), dia)
    }
    novant = Datas.diferencaAnos(dtbase, dfin) / 4
    novant = Numeros.trunca(novant, 0)
}
if (novant < 1) {
    suspender 'O funcionário ainda não adquiriu o adicional'
}
if (vvar > 0) {
    valorReferencia = vvar
} else {
    if (vvarFgts > 0) {
        valorReferencia = vvarFgts
    } else {
        if (rh == 1) {
            valorReferencia = AdicionaisTempoServico.busca(TipoAdicional.PERCENTUAL_TEMPO_SERVICO, ClassificacaoAdicional.QUADRIENIO)
        } else {
            def taxa = evento.taxa
            def vaux
            if (forma == 1 || novant == 1) {
                vaux = novant * taxa
            } else {
                taxa /= 100
                vaux = 1 + taxa
                vaux = ((vaux ^ novant) - 1) / taxa
                vaux *= taxa * 100
            }
            if (vaux > 35) {
                vaux = 35 //Vai parar de gerar em 35%
            }
            valorReferencia = vaux
        }
    }
}
def vcal = (funcionario.salario * valorReferencia) / 100
if (vcal > 0) {
    if (TipoProcessamento.DECIMO_TERCEIRO_SALARIO.equals(calculo.tipoProcessamento)) {
        vcal *= Funcoes.avos13(12) / 12
        if (SubTipoProcessamento.ADIANTAMENTO.equals(calculo.subTipoProcessamento)) {
            vcal *= 50 / evento.getTaxa(26)
        }
        valorCalculado = vcal
        valBaseFgts = vcal
    } else {
        def base = 0
        if (Eventos.valor(195) > 0) {
            base = Bases.valor(Bases.PAGAPROP) - Bases.valor(Bases.MEDAUXMATPR)
        } else {
            base = Bases.valor(Bases.PAGAPROP)
        }
        if (base > 0 && !somenteFgts) {
            Bases.compor(vcal, Bases.HORAEXTRA, Bases.SALAFAM)
        }
        valorCalculado = Funcoes.calcprop(vcal, base)
        afastamentos = [ClassificacaoTipoAfastamento.ACIDENTE_DE_TRABALHO_PREVIDENCIA,
                        ClassificacaoTipoAfastamento.SERVICO_MILITAR]
        base += Funcoes.cnvdpbase(Funcoes.diasafastcalc30(calculo.competencia, afastamentos))
        valBaseFgts = Funcoes.calcprop(vcal, base)
    }
    if (!somenteFgts) {
        Bases.compor(valorCalculado, Bases.SALBASE, Bases.PERIC, Bases.IRRF, Bases.INSS, Bases.MEDIAUXMAT)
        Bases.compor(valorCalculado, Bases.PREVEST, Bases.FUNDASS, Bases.FUNDOPREV, Bases.FUNDFIN)
    }
    Bases.compor(valBaseFgts, Bases.FGTS)
}
