//Este evento demonstra na folha mensal o valor calculado de previdência própria de férias de forma proporcional, conforme os dias de férias em cada competência, quando o parâmetro 'Replicar eventos do cálculo de férias para o cálculo mensal' está ativo
if (!TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
    suspender \"O evento deve ser calculado apenas em processamentos mensais\"
}
Funcoes.somenteFuncionarios()
if (funcionario.possuiPrevidencia(TipoPrevidencia.PREVIDENCIA_PROPRIA)) {
    double vaux = Lancamentos.valor(evento)
    if (vaux > 0) {
        valorCalculado = vaux
    } else {
        prevPropriaFerias = Funcoes.getPrevPropriaFerias()
        valorReferencia = prevPropriaFerias.referencia
        valorCalculado = prevPropriaFerias.valor
    }
    if (valorCalculado > 0) {
        evento.replicado(true)
    }
}
