suspender 'Este evento foi descontinuado. Os recessos por padrão serão pagas somente em uma competência'
