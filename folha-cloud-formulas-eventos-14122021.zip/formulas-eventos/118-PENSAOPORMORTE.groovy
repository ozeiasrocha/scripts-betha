if (!TipoMatricula.PENSIONISTA.equals(matricula.tipo)) {
    suspender \"Este cálculo é executado apenas para pensionistas\"
}
def dataCessacaoBeneficio = pensionista.dataCessacaoBeneficio
def inicioCompetencia = Datas.data(Datas.ano(calculo.competencia), Datas.mes(calculo.competencia), 1)
if (!dataCessacaoBeneficio || (dataCessacaoBeneficio >= inicioCompetencia)) {
    valorCalculado = 0
    def vvar = Lancamentos.valor(evento)
    if (vvar > 0) {
        valorCalculado = vvar
    } else {
        valorCalculado = pensionista.valorBeneficio
    }
    if (valorCalculado > 0) {
        Bases.compor(valorCalculado,
                Bases.IRRF,
                Bases.INSS,
                Bases.PREVEST,
                Bases.FUNDASS,
                Bases.FUNDOPREV,
                Bases.FUNDFIN,
                Bases.SALAFAM,
                Bases.PARCISENIRRF)
    }
}
