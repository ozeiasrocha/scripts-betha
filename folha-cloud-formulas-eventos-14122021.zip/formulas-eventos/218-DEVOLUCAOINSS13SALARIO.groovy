//Este evento deve ser configurado para calcular por último (Guia Geral > Calcular por último)
if (!TipoMatricula.FUNCIONARIO.equals(matricula.tipo) && !TipoMatricula.AUTONOMO.equals(matricula.tipo)) {
    suspender \"Este cálculo é executado apenas para funcionários ou autônomos\"
}
if (Funcoes.possuiPrevidenciaFederal(matricula.tipo)) {
    if (TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && SubTipoProcessamento.COMPLEMENTAR.equals(calculo.subTipoProcessamento)) {
        def vvar = Lancamentos.valor(evento)
        if (vvar > 0) {
            valorReferencia = vvar
            valorCalculado = vvar
        }
    }
}
