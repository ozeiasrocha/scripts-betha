Funcoes.somenteFuncionarios()
def optanteFgts = Funcoes.optanteFgts(matricula.tipo)
if (!optanteFgts) {
    suspender \"A matrícula não é optante de FGTS\"
}
def vaux = Lancamentos.valor(evento)
if (vaux > 0) {
    valorCalculado = vaux
    valorReferencia = vaux
} else {
    def base = 0
    def saldoFGTS = calculo.saldoFgts
    if (calculo.motivoRescisao.classificacao.equals('ACORDO_ENTRE_PARTES')) {
        // Rescisão por Acordo
        // Conforme legislação, dividir o valor da referência por 2 para rescisões por acordo
        def referencia = evento.taxa
        valorReferencia = referencia / 2
    } else {
        valorReferencia = evento.taxa
    }
    base = Eventos.valor(36) + Eventos.valor(37) + Eventos.valor(113) + Eventos.valor(114)
    base += Eventos.valorCalculado(37, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.ADIANTAMENTO)
    base += Eventos.valorCalculado(37, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL)
    base += saldoFGTS - Eventos.valor(251)
    valorCalculado = base * valorReferencia / 100
}
