Funcoes.somenteFuncionarios()
if (funcionario.possuiPrevidenciaFederal) {
    valorReferencia = Funcoes.mesesmat13()
    if (valorReferencia > 0) {
        valorCalculado = Bases.valor(Bases.INSS13) * valorReferencia / Funcoes.avos13(12)
        if (valorCalculado > 0) {
            Bases.compor(valorCalculado, Bases.IRRF13, Bases.ABATIRRF13)
        }
    }
}
