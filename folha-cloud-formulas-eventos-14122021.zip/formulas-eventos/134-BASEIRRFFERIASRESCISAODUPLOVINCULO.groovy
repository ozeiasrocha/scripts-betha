Funcoes.somenteFuncionarios()
if (TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento)) {
    def vaux = Lancamentos.valor(evento)
    if (vaux >= 0) {
        valorReferencia = vaux
    } else {
        valorReferencia = Funcoes.getValorBaseMultiplosVinculos(Bases.IRRFFERRESC, calculo.tipoProcessamento, calculo.subTipoProcessamento)
    }
    valorCalculado = valorReferencia
}
