if (!TipoMatricula.AUTONOMO.equals(matricula.tipo)) {
    suspender \"Este cálculo é executado apenas para autônomos\"
}
def vaux = Lancamentos.valor(evento)
if (vaux > 0) {
    valorReferencia = 0
    valorCalculado = vaux
} else {
    def salario = autonomo.totalServicosAutonomo
    if (salario <= 0) {
        suspender \"Não há valor de serviços lançados para o autônomo na competência\"
    }
    valorReferencia = 0
    valorCalculado = salario
}
Bases.compor(valorCalculado,
        Bases.INSS,
        Bases.SALBASE,
        Bases.IRRF,
        Bases.COMPHORAMES)
