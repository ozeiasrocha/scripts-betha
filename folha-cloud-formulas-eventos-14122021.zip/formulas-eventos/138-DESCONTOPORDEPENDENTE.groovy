Funcoes.somenteFuncionarios()
def vaux = Lancamentos.valor(evento)
if (vaux > 0) {
    valorCalculado = vaux
} else {
    def valor13 = Eventos.valor(25) + Eventos.valor(28) + Eventos.valor(29) + Eventos.valor(30)
    if ((TipoProcessamento.DECIMO_TERCEIRO_SALARIO.equals(calculo.tipoProcessamento) && SubTipoProcessamento.INTEGRAL.equals(calculo.subTipoProcessamento) && valor13 <= 0) ||
        ((TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && (Bases.valor(Bases.PAGAPROP) <= 0 && TipoMatricula.AUTONOMO.equals(matricula.tipo))) ||
         (Bases.valor(Bases.SALBASE) <= 0 && TipoMatricula.AUTONOMO.equals(matricula.tipo)) && valor13 <= 0)) {
        suspender 'Não há valor para cálculo do desconto por dependente'
    }
    valorReferencia = servidor.dependentesIrrf
    valorCalculado = valorReferencia * EncargosSociais.IRRF.deducaoPorDependente
    if (funcionario.possuiMultiploVinculo){
        def valorCalculadoEventoMultiploVinculo = Eventos.valorCalculadoMultiplosVinculos(evento.codigo, TipoValor.CALCULADO, calculo.tipoProcessamento, calculo.subTipoProcessamento)
        if (TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
            valorCalculadoEventoMultiploVinculo += Eventos.valorCalculadoMultiplosVinculos(evento.codigo, TipoValor.CALCULADO, TipoProcessamento.RESCISAO, SubTipoProcessamento.INTEGRAL)
        }
        if (TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento)) {
            valorCalculadoEventoMultiploVinculo += Eventos.valorCalculadoMultiplosVinculos(evento.codigo, TipoValor.CALCULADO, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL)
        }
        if (valorCalculadoEventoMultiploVinculo > 0) {
            suspender \"O desconto por dependente já foi calculado em outra matrícula do múltiplo vínculo\"
        }
    }
}
if (calculo.tipoProcessamento == TipoProcessamento.FERIAS){
    Bases.compor(valorCalculado, Bases.IRRF, Bases.IRRFFER)
} else if (calculo.tipoProcessamento == TipoProcessamento.DECIMO_TERCEIRO_SALARIO) {
    Bases.compor(valorCalculado, Bases.IRRF13)
} else {
    Bases.compor(valorCalculado, Bases.IRRF, Bases.IRRF13, Bases.IRRFFERRESC)
}
