Funcoes.somenteFuncionarios()
def optanteFgts = Funcoes.optanteFgts(matricula.tipo)
if (!optanteFgts) {
    suspender \"A matrícula não é optante de FGTS\"
}
def vaux = Lancamentos.valor(evento)
if (vaux >= 0) {
    valorReferencia = vaux
    valorCalculado = vaux
} else {
    double fgtsaux
    double baseaux
    baseaux += Bases.valorCalculado(Bases.FGTS13, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL)
    baseaux += Bases.valorCalculado(Bases.FGTS13, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.ADIANTAMENTO)
    if (Bases.valor(Bases.FGTS13) > 0) {
        baseaux += Bases.valor(Bases.FGTS13)
    }
    if (baseaux > 0) {
        fgtsaux += Eventos.valor(37)
        fgtsaux += Eventos.valorCalculado(37, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL)
        fgtsaux += Eventos.valorCalculado(37, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.ADIANTAMENTO)
    }
    if (Eventos.valor(904) > 0) {
        fgtsaux += Eventos.valor(904)
    }
    def base = Bases.valor(Bases.FGTS)
    if ((!(TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && SubTipoProcessamento.COMPLEMENTAR.equals(calculo.subTipoProcessamento)) &&
         !(TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento) && SubTipoProcessamento.COMPLEMENTAR.equals(calculo.subTipoProcessamento))) && (baseaux > 0)) {
        base += baseaux
    }
    if (funcionario.categoriaSefipVinculo.toString() == 'MENOR_APRENDIZ') {
        valorReferencia = 2
    } else {
        valorReferencia = evento.taxa
    }
    vaux = base * valorReferencia / 100
    if (!(TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && SubTipoProcessamento.COMPLEMENTAR.equals(calculo.subTipoProcessamento)) &&
        !(TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento) && SubTipoProcessamento.COMPLEMENTAR.equals(calculo.subTipoProcessamento))) {
        vaux -= fgtsaux
    }
    valorCalculado = Numeros.trunca(vaux,2)
}
