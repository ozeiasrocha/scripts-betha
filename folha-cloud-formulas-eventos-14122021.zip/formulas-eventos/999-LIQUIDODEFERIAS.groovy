if (!TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
    suspender \"O evento deve ser calculado apenas em processamentos mensais\"
}
double liquidoFerias
double vaux = Lancamentos.valor(evento)
if (vaux > 0) {
    liquidoFerias = vaux
} else {
    valorFerias = Funcoes.getTotalFerias()
    liquidoFerias = valorFerias.liquido - Eventos.valor(900) + Eventos.valor(901)
}
if (liquidoFerias > 0) {
    valorCalculado = liquidoFerias
    evento.replicado(true)
}
