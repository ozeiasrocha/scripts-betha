Funcoes.somenteFuncionarios()
def avisoinden = Funcoes.avisoPrevioIndenizado()
if (!avisoinden) {
    suspender 'Não há aviso prévio a ser indenizado ao funcionário'
}
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
boolean permitecalc13integral = Funcoes.permitecalc13integral()
if (!permitecalc13integral) {
    suspender \"O período aquisitivo de décimo terceiro já foi quitado ou o evento está sendo calculado em um processamento diferente de 'Mensal' ou 'Rescisão'\"
}
def vvar = Lancamentos.valor(evento)
valorReferencia = 1
if (vvar > 0) {
    valorCalculado = vvar
} else {
    valorCalculado = Funcoes.remuneracao(matricula.tipo).valor / 12
}
if (valorCalculado > 0) {
    def mesproc = Datas.mes(calculo.competencia)
    def avos13 = Funcoes.avos13(12)
    if (mesproc == 1 && avos13 <= 0) {
        Bases.compor(valorCalculado, Bases.IRRF13)
    } else {
        Bases.compor(valorCalculado, Bases.IRRF13, Bases.INSS13, Bases.FGTS13)
    }
}
