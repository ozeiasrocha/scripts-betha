if (!calculo.replicaEventosCalculoFeriasParaCalculoMensal) {
    suspender \"Este evento será calculado apenas para entidades que estão configuradas para replicar os eventos do cálculo de férias no cálculo mensal\"
}
if (!TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && !TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento)) {
    suspender \"O evento deve ser calculado apenas em processamentos mensais ou rescisórios\"
}
def vvar = Lancamentos.valor(evento)
if (vvar > 0) {
    valorCalculado = vvar
}
