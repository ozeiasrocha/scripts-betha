Funcoes.somenteFuncionarios()
def optanteFgts = Funcoes.optanteFgts(matricula.tipo)
if (!optanteFgts) {
    suspender \"A matrícula não é optante de FGTS\"
}
def vaux = Lancamentos.valor(evento)
if (vaux > 0) {
    valorReferencia = vaux
    valorCalculado = vaux
} else {
    double basecompanterior = 0
    def companterior = Datas.removeMeses(calculo.competencia, 1)
    if (Eventos.valorCalculado(36, TipoValor.CALCULADO, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL, companterior) <= 0) {
        basecompanterior += Bases.valorCalculado(Bases.FGTS, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL, companterior)
    }
    if (Eventos.valorCalculado(36, TipoValor.CALCULADO, TipoProcessamento.MENSAL, SubTipoProcessamento.COMPLEMENTAR, companterior) <= 0) {
        basecompanterior += Bases.valorCalculado(Bases.FGTS, TipoProcessamento.MENSAL, SubTipoProcessamento.COMPLEMENTAR, companterior)
    }
    if (Eventos.valorCalculado(86, TipoValor.CALCULADO, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL, companterior) <= 0) {
        basecompanterior += Bases.valorCalculado(Bases.FGTS, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL, companterior)
    }
    if (Eventos.valorCalculado(37, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.ADIANTAMENTO, companterior) <= 0) {
        basecompanterior += Bases.valorCalculado(Bases.FGTS13, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.ADIANTAMENTO, companterior)
    }
    if (Eventos.valorCalculado(37, TipoValor.CALCULADO, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL, companterior) <= 0) {
        basecompanterior += Bases.valorCalculado(Bases.FGTS13, TipoProcessamento.DECIMO_TERCEIRO_SALARIO, SubTipoProcessamento.INTEGRAL, companterior)
    }
    if (basecompanterior > 0) {
        valorReferencia = 0
        valorCalculado = basecompanterior
    }
}
