Funcoes.somenteFuncionarios()
if (Eventos.valorCalculado(evento.codigo, TipoValor.CALCULADO, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL) > 0 && (TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && SubTipoProcessamento.COMPLEMENTAR.equals(calculo.subTipoProcessamento))) {
    suspender \"Este evento já foi calculado no processamento mensal (integral)\"
}
if (!funcionario.possuiPrevidenciaFederal) {
    suspender \"Calcular apenas para previdência federal\"
}
def vaux = Lancamentos.valor(evento)
if (vaux <= 0) {
    boolean mensalIntegral = (TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && SubTipoProcessamento.INTEGRAL.equals(calculo.subTipoProcessamento))
    if ((TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento) && periodoConcessao.diasGozo > 0) || mensalIntegral) {
        vaux = BasesOutrasEmpresas.buscaPor(TipoProcessamento.MENSAL).sum(0, { it.valorRetidoInss })
    } else {
        vaux = BasesOutrasEmpresas.buscaPor(calculo.tipoProcessamento).sum(0, { it.valorRetidoInss })
    }
}
if (vaux <= 0){
    suspender \"Não é possível calcular a retenção I.N.S.S. de outras empresas para funcionários que na competência não tenham o valor lançado para o cálculo\"
}
valorCalculado = 0
if (TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento) && periodoConcessao.diasGozo > 14) {
    valorCalculado = Funcoes.calcprop(vaux, Funcoes.cnvdpbase(30))
} else {
    if (TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
        if (((funcionario.unidadePagamento.equals(UnidadePagamento.HORISTA)) || (funcionario.unidadePagamento.equals(UnidadePagamento.DIARISTA))) && (calculo.quantidadeDiasCompetencia == 31)) {
            valorCalculado = Funcoes.calcprop(vaux, Funcoes.cnvdpbase(31))
        } else {
            valorCalculado = Funcoes.calcprop(vaux, Funcoes.cnvdpbase(30))
        }
    }
}
