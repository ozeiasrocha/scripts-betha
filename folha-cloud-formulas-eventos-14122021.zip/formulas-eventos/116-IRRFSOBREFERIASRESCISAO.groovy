Funcoes.somenteFuncionarios()
def desc = 0
def vaux = Lancamentos.valor(evento)
if (vaux >= 0) {
    valorCalculado = vaux
    desc = EncargosSociais.IRRF.buscaContribuicao(vaux, 3)
} else {
    def base = Bases.valor(Bases.IRRFFERRESC)
    valorCalculado = 0
    if (base >= EncargosSociais.IRRF.buscaContribuicao(0, 1)) {
        desc = EncargosSociais.IRRF.buscaContribuicao(base, 3)
        valorReferencia = EncargosSociais.IRRF.buscaContribuicao(base, 2)
        valorCalculado = (base * valorReferencia / 100) - desc
    }
}
if (valorCalculado < EncargosSociais.IRRF.minimoIrrfDarf) {
    valorCalculado = 0
} else {
    Bases.compor(desc, Bases.DESCIRRF)
}
