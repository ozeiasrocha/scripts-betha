Funcoes.somenteFuncionarios()
boolean mensalComplementar = TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && SubTipoProcessamento.COMPLEMENTAR.equals(calculo.subTipoProcessamento)
boolean mensalIntegral = (TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento) && SubTipoProcessamento.INTEGRAL.equals(calculo.subTipoProcessamento))
if (Eventos.valorCalculado(evento.codigo, TipoValor.CALCULADO, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL) > 0 && mensalComplementar) {
    suspender \"Este evento já foi calculado no processamento mensal integral\"
}
def vaux = Lancamentos.valor(evento)
if (vaux <= 0) {
    if ((TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento) && periodoConcessao.diasGozo > 0) || mensalIntegral) {
        vaux = BasesOutrasEmpresas.buscaPor(TipoProcessamento.MENSAL).sum(0, { it.baseIrrf })
    } else {
        vaux = BasesOutrasEmpresas.buscaPor(calculo.tipoProcessamento).sum(0, { it.baseIrrf })
    }
}
if (vaux <= 0) {
    suspender \"Não é possível calcular a base I.R.R.F. de outras empresas para funcionários que na competência não tenham o valor lançado para o cálculo ou que não tenham valor de base 'Paga proporcional'\"
}
if (vaux > 0) {
    valorCalculado = vaux
    Bases.compor(valorCalculado, Bases.IRRFOUTRA)
}
