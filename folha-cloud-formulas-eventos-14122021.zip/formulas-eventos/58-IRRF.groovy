double desc = 0
double vaux2 = 0
vaux = Lancamentos.valor(evento)
if (vaux >= 0) {
    valorCalculado = vaux
    vaux2 = Numeros.trunca(vaux, 2)
    desc = EncargosSociais.IRRF.buscaContribuicao(vaux2, 3)
} else {
    def baseOutrosVinculos = 0
    if (!TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento)) {
        baseOutrosVinculos = Funcoes.getValorBaseMultiplosVinculos(Bases.IRRF, calculo.tipoProcessamento, calculo.subTipoProcessamento)
    }
    def irrfOutrosVinculos = 0
    if (baseOutrosVinculos > 0) {
        irrfOutrosVinculos = Eventos.valorCalculadoMultiplosVinculos(evento.codigo, TipoValor.CALCULADO, calculo.tipoProcessamento, calculo.subTipoProcessamento)
        if (TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento)) {
            irrfOutrosVinculos += Eventos.valorCalculadoMultiplosVinculos(evento.codigo, TipoValor.CALCULADO, calculo.tipoProcessamento, calculo.subTipoProcessamento)
        }
    }
    double base = Bases.valor(Bases.IRRF) - Eventos.valor(135) - Eventos.valor(189) - Eventos.valor(192) + Bases.valor(Bases.IRRFOUTRA) + baseOutrosVinculos
    if (SubTipoProcessamento.COMPLEMENTAR.equals(calculo.subTipoProcessamento)) {
        base += Bases.valorCalculado(Bases.IRRFOUTRA, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL)
    }
    valorCalculado = 0
    if (base >= EncargosSociais.IRRF.buscaContribuicao(0, 1)) {
        vaux2 = Numeros.trunca(base, 2)
        desc = EncargosSociais.IRRF.buscaContribuicao(vaux2, 3)
        valorReferencia = EncargosSociais.IRRF.buscaContribuicao(vaux2, 2)
        valorCalculado = ((vaux2 * valorReferencia) / 100) - desc - irrfOutrosVinculos - Eventos.valor(173)
    }
}
if (valorCalculado < EncargosSociais.IRRF.minimoIrrfDarf) {
    valorCalculado = 0
} else {
    Bases.compor(desc, Bases.DESCIRRF)
}
