def vvar = Lancamentos.valor(evento)
def base = Bases.valor(Bases.SALBASE)
if (vvar > 0) {
    valorReferencia = (vvar * 100) / base
    valorCalculado = vvar
} else {
    valorReferencia = evento.taxa
    valorCalculado = base * valorReferencia / 100
}
if (valorCalculado > 0) {
    Bases.compor(valorCalculado, Bases.IRRF)
}
