Funcoes.carregaEmprestimoEmFerias(true)
def vvar = Lancamentos.valor(evento)
if (vvar > 0) {
    double vlrCalc = vvar - Eventos.valorCalculado(evento.codigo, TipoValor.CALCULADO, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL)
    if (vlrCalc > 0) {
        valorReferencia = vlrCalc
        valorCalculado = vlrCalc
    }
} else {
    if (TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento) && calculo.descontarEmprestimoRescisao) {
        valorCalculado = Funcoes.emprestimos()
    } else {
        valorCalculado = Funcoes.emprestimos(calculo.competencia)
    }
}
