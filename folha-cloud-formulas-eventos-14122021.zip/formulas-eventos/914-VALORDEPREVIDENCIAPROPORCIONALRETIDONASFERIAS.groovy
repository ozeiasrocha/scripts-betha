if (!TipoProcessamento.MENSAL.equals(calculo.tipoProcessamento)) {
    suspender \"O evento deve ser calculado apenas em processamentos mensais\"
}
Funcoes.somenteFuncionarios()
if (Funcoes.quantPrevidenciasAtivas() > 0) {
    double valorRetido
    double vaux = Lancamentos.valor(evento)
    if (vaux > 0) {
        valorRetido = vaux
    } else {
        def valorPrevidFeriasIntegral = Funcoes.getValorCodigoEventoFerias(88, true).valor + Funcoes.getValorCodigoEventoFerias(89, true).valor + Funcoes.getValorCodigoEventoFerias(90, true).valor + Funcoes.getValorCodigoEventoFerias(91, true).valor + Funcoes.getValorCodigoEventoFerias(249, true).valor
        if (valorPrevidFeriasIntegral > 0) {
            def valorPrevidFeriasDoMes = Eventos.valor(902) + Eventos.valor(905) + Eventos.valor(906) + Eventos.valor(907) + Eventos.valor(908)
            valorRetido = valorPrevidFeriasIntegral - valorPrevidFeriasDoMes
        }
    }
    if (valorRetido > 0) {
        valorCalculado = valorRetido
        evento.replicado(true)
    }
}
