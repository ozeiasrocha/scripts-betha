Funcoes.somenteFuncionarios()
if (!servidor.sexo.equals(Sexo.FEMININO)) {
    suspender \"Este cálculo é realizado apenas para funcionários do sexo feminino\"
}
if (!funcionario.possuiPrevidencia(TipoPrevidencia.FUNDO_FINANCEIRO)) {
    suspender \"Este cálculo é realizado apenas para funcionários contribuintes do fundo financeiro\"
}
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
def base = Bases.valor(Bases.FUNDFIN13) - Bases.valor(Bases.DESC13REINT)
if (base <= 0) {
    suspender 'Não há valor de base de fundo financeiro décimo terceiro ou desconto de décimo terceiro devido reintegração para cálculo'
}
def vlrCalc = 0
def vlrDeduz = 0
def inicio
def fim
if (TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento)) {
    inicio = Datas.data(Datas.ano(calculo.competencia), 1, 1)
    fim = Datas.data(Datas.ano(funcionario.dataRescisao), Datas.mes(funcionario.dataRescisao), Datas.dia(funcionario.dataRescisao))
    vlrCalc = Funcoes.deducauxmat13(base, Funcoes.avos13(Datas.mes(calculo.competencia)), 1)
} else {
    inicio = Datas.data(Datas.ano(calculo.competencia), 1, 1)
    fim = Datas.data(Datas.ano(calculo.competencia), 12, 1)
    vlrCalc = Funcoes.deducauxmat13(base, Funcoes.avos13(12),1)
}
vlrDeduz = Funcoes.acumula(evento.codigo, TipoValor.CALCULADO, inicio, fim, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL) + Funcoes.acumula(evento.codigo, TipoValor.CALCULADO, inicio, fim, TipoProcessamento.FERIAS, SubTipoProcessamento.INTEGRAL)
vlrCalc -= vlrDeduz
valorCalculado = vlrCalc
