Funcoes.somenteFuncionarios()
if (!funcionario.possuiPrevidenciaFederal) {
    suspender \"Este cálculo é realizado apenas para funcionários contribuintes da previdência federal\"
}
def vaux = Lancamentos.valor(evento);
if (vaux <= 0) {
    boolean mesDemissao
    def dataRescisao = calculo.dataRescisao
    if (dataRescisao != null) {
        if (Datas.ano(dataRescisao) == Datas.ano(calculo.competencia) && Datas.mes(dataRescisao) == Datas.mes(calculo.competencia) && calculo.quantidadeDiasCompetencia >= Datas.dia(dataRescisao)) {
            mesDemissao = true
        }
    }
    if (mesDemissao) {
        vaux = BasesOutrasEmpresas.buscaPor(TipoProcessamento.DECIMO_TERCEIRO_SALARIO).sum(0, { it.baseInss })
    } else {
        vaux = BasesOutrasEmpresas.buscaPor(calculo.tipoProcessamento).sum(0, { it.baseInss })
    }
}
if (vaux <= 0){
    suspender \"Não é possível calcular a base I.N.S.S. de outras empresas em décimo terceiro para funcionários que na competência não tenham o valor lançado para o cálculo\"
}
valorCalculado = vaux
Bases.compor(valorCalculado, Bases.INSSOUTRA13)
