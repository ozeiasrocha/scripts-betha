if (TipoMatricula.PENSIONISTA.equals(matricula.tipo)) {
    suspender \"Este cálculo não é executado para pensionistas\"
}
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
boolean permitecalc13integral = Funcoes.permitecalc13integral()
if (!permitecalc13integral) {
    suspender \"O período aquisitivo de décimo terceiro já foi quitado ou o evento está sendo calculado em um processamento diferente de 'Mensal' ou 'Rescisão'\"
}
def salario = 0
def vvar = Lancamentos.valor(evento)
if (TipoMatricula.APOSENTADO.equals(matricula.tipo)) {
    if (Funcoes.diasaposent() > 0) {
        if (aposentado.dataCessacaoAposentadoria != null) {
            if (Datas.data(calculo.competencia.ano, calculo.competencia.mes, 1) == Datas.data(aposentado.dataCessacaoAposentadoria.ano, aposentado.dataCessacaoAposentadoria.mes, 1)) {
                valorReferencia = Funcoes.avos13(Datas.mes(calculo.competencia))
            }
        } else {
            valorReferencia = Funcoes.avos13(12)
        }
        if (vvar >= 0) {
            valorCalculado = vvar
        } else {
            salario = Funcoes.remuneracao(matricula.tipo).valor
            valorCalculado = salario * valorReferencia / 12
        }
    }
} else {
    double vlrreffgts = 0
    double vlrcalcfgts = 0
    if (Funcoes.dtrescisao()) {
        valorReferencia = Funcoes.avos13(Datas.mes(calculo.competencia))
        vlrreffgts = Funcoes.avos13(Datas.mes(calculo.competencia), true)
    } else {
        valorReferencia = Funcoes.avos13(12)
        vlrreffgts = Funcoes.avos13(12, true)
    }
    if (valorReferencia <= 0) {
        suspender \"Não há avos adquiridos no período aquisitivo de décimo terceiro\"
    }
    if (vvar >= 0) {
        valorCalculado = vvar
        vlrcalcfgts = vvar * vlrreffgts / valorReferencia
    } else {
        salario = Funcoes.remuneracao(matricula.tipo).valor
        valorCalculado = salario * valorReferencia / 12
        vlrcalcfgts = salario * vlrreffgts / 12
    }
    Bases.compor(vlrcalcfgts, Bases.FGTS13)
}
Bases.compor(valorCalculado,
        Bases.IRRF13,
        Bases.INSS13,
        Bases.PREVEST13,
        Bases.FUNDASS13,
        Bases.FUNDPREV13,
        Bases.FUNDFIN13)
