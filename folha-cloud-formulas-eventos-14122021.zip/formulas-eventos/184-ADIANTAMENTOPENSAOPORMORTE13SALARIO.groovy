if (!TipoMatricula.PENSIONISTA.equals(matricula.tipo)) {
    suspender \"Este cálculo é executado apenas para pensionistas\"
}
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
boolean permitecalc13integral = Funcoes.permitecalc13integral()
if (!permitecalc13integral) {
    suspender \"O período aquisitivo de décimo terceiro já foi quitado ou o evento está sendo calculado em um processamento diferente de 'Mensal' ou 'Rescisão'\"
}
vaux = Lancamentos.valor(evento)
if (vaux >= 0) {
    valorCalculado = vaux
} else {
    double valorAdiantado = PeriodosAquisitivosDecimoTerceiro.buscaPeriodosAquisitivosBySituacao(SituacaoPeriodoAquisitivoDecimoTerceiro.QUITADO_PARCIALMENTE).sum(0, {
        it.anoExercicio == calculo.anoDecimoTerceiro || pensionista.dataCessacaoBeneficio ? it.totalMovimentacoes : 0
    })
    if (valorAdiantado <= 0) {
        suspender \"Não há valores adiantados de décimo terceiro no período aquisitivo deste pensionista\"
    }
    valorCalculado = valorAdiantado - Eventos.valor(200)
}
