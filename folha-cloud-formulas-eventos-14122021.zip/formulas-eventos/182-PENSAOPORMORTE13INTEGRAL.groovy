if (!TipoMatricula.PENSIONISTA.equals(matricula.tipo)) {
    suspender \"Este cálculo é executado apenas para pensionistas\"
}
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
if (!(TipoProcessamento.DECIMO_TERCEIRO_SALARIO.equals(calculo.tipoProcessamento) && SubTipoProcessamento.INTEGRAL.equals(calculo.subTipoProcessamento))) {
    suspender \"O evento deve ser calculado apenas em processamentos de décimo terceiro (integral)\"
}
boolean permitecalc13integral = Funcoes.permitecalc13integral()
if (!permitecalc13integral) {
    suspender \"O período aquisitivo de décimo terceiro já foi quitado ou o evento está sendo calculado em um processamento diferente de 'Mensal' ou 'Rescisão'\"
}
def dataCessacaoBeneficio = pensionista.dataCessacaoBeneficio
def inicioCompetencia = Datas.data(Datas.ano(calculo.competencia), Datas.mes(calculo.competencia), 1)
if (!dataCessacaoBeneficio || (dataCessacaoBeneficio >= inicioCompetencia)) {
    valorCalculado = 0
    def vvar = Lancamentos.valor(evento)
    if (vvar > 0) {
        valorCalculado = vvar
    } else {
        valorCalculado = pensionista.valorBeneficio * Funcoes.avos13(12) / 12
    }
    if (valorCalculado > 0) {
        Bases.compor(valorCalculado,
                Bases.IRRF13,
                Bases.INSS13,
                Bases.PREVEST13,
                Bases.FUNDASS13,
                Bases.FUNDPREV13,
                Bases.FUNDFIN13,
                Bases.PAISIR13SA)
    }
}
