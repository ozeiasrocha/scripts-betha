Funcoes.somenteAposentadosPensionistas()
if (!Funcoes.possuiPrevidencia(TipoPrevidencia.PREVIDENCIA_PROPRIA)) {
    suspender \"Este cálculo é realizado apenas para funcionários contribuintes da previdência própria\"
}
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
def vaux = EncargosSociais.IRRF.buscaContribuicao(0, 1)
def vbase = Bases.valor(Bases.FUNDPREV13)
if (vbase < vaux) {
    vaux = vbase
}
valorCalculado = vaux
