Funcoes.somenteFuncionarios()
def valorFerias = Funcoes.replicaFeriasNaFolhaMensal(evento.codigo)
if (valorFerias.valor > 0) {
    Bases.compor(valorFerias.valor,
            Bases.INSSFER,
            Bases.FUNDOPREVFER,
            Bases.FUNDASSFER,
            Bases.PREVESTFER,
            Bases.FUNDFINFER,
            Bases.FGTS)
}
valorCalculado = valorFerias.valor
valorReferencia = valorFerias.referencia
if (TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento)) {
    if (periodoAquisitivo.pagouUmTercoIntegral) {
        suspender 'O evento de 1/3 das férias já foi calculado integralmente em gozo de férias fracionadas anteriores'
    }
    if (folha.folhaPagamento) {
        valorReferencia = evento.taxa
        valorCalculado = 0
        folhas.buscaFolhas().each { f ->
            f.eventos.each { e ->
                if (e.codigo == evento.codigo) {
                    valorCalculado += e.valor
                }
            }
        }
        if (valorCalculado > 0) {
            Bases.compor(valorCalculado,
                    Bases.FGTS,
                    Bases.DESCTERFER,
                    Bases.IRRFFER,
                    Bases.INSSFER,
                    Bases.PREVEST,
                    Bases.FUNDASS,
                    Bases.FUNDOPREV,
                    Bases.FUNDFIN,
                    Bases.MEDIAUXMAT)
        }
    } else {
        def vaux = Lancamentos.valor(evento)
        if (vaux >= 0) {
            valorReferencia = evento.taxa
            valorCalculado = vaux
        } else {
            vaux = Eventos.valor(75) + Eventos.valor(80) + Eventos.valor(81) + Eventos.valor(82) + Eventos.valor(234)
            if (calculo.pagarUmTercoIntegral && !folha.calculoVirtual) {
                if (Datas.ano(periodoConcessao.dataInicioGozo) == Datas.ano(calculo.competencia) && Datas.mes(periodoConcessao.dataInicioGozo) == Datas.mes(calculo.competencia)) {
                    def diasferprop = folha.diasGozo
                    def diasdirfer = periodoAquisitivo.configuracaoFerias.diasParaAdquirirNoPeriodo
                    def diasgozo = periodoConcessao.diasGozo
                    def diasabono = periodoConcessao.diasAbono
                    vaux = (vaux * (diasgozo / diasferprop) * (diasdirfer - diasabono) / diasgozo)
                    vaux = Numeros.arredonda(vaux, 2)
                } else {
                    vaux = 0
                }
            }
            valorReferencia = evento.taxa
            valorCalculado = vaux * evento.taxa / 100
        }
    }
}
