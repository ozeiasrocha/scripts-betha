Funcoes.somenteFuncionarios()
def optanteFgts = Funcoes.optanteFgts(matricula.tipo)
if (!optanteFgts) {
    suspender \"A matrícula não é optante de FGTS\"
}
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
if (folha.folhaPagamento) {
    double vaux = Lancamentos.valor(evento)
    if (vaux > 0) {
        valorReferencia = vaux
        valorCalculado = vaux
    } else {
        if (funcionario.categoriaSefipVinculo.toString() == 'MENOR_APRENDIZ') {
            valorReferencia = 2
        } else {
            valorReferencia = evento.taxa
        }
        double baseaux
        double fgtsaux
        vaux = Eventos.valorCalculado(36, TipoValor.CALCULADO, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL)
        vaux += Eventos.valorCalculado(904, TipoValor.CALCULADO, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL)
        if (TipoProcessamento.DECIMO_TERCEIRO_SALARIO.equals(calculo.tipoProcessamento) && vaux > 0) {
            baseaux += Bases.valorCalculado(Bases.FGTS, TipoProcessamento.MENSAL, SubTipoProcessamento.INTEGRAL)
            if (baseaux > 0) {
                fgtsaux = vaux
            }
            vaux = Bases.valor(Bases.FGTS13) + baseaux
            vaux = vaux * (valorReferencia / 100)
            vaux = vaux - fgtsaux
            valorCalculado = vaux.trunc(2)
        } else {
            vaux = Bases.valor(Bases.FGTS13) * valorReferencia / 100
            valorCalculado = vaux.trunc(2)
        }
    }
}
