suspender 'Este evento foi descontinuado. As férias por padrão serão pagas somente em uma competência'
