Funcoes.somenteFuncionarios()
boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
if (!recebeDecimoTerceiro) {
    suspender \"A matrícula não tem direito a receber décimo terceiro\"
}
boolean permitecalc13integral = Funcoes.permitecalc13integral()
if (!permitecalc13integral) {
    suspender \"O período aquisitivo de décimo terceiro já foi quitado ou o evento está sendo calculado em um processamento diferente de 'Mensal' ou 'Rescisão'\"
}
def periodoAtual
double vlrreffgts = 0
double vlrrefproc = 0
double vlrcalcfgts = 0
if (calculo.dataRescisao && TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento)) {
    vlrrefproc = Funcoes.avos13(Datas.mes(calculo.competencia))
    vlrreffgts = Funcoes.avos13(Datas.mes(calculo.competencia), true)
    PeriodosAquisitivosDecimoTerceiro.buscaPeriodosAquisitivosBySituacao(
            SituacaoPeriodoAquisitivoDecimoTerceiro.ATRASADO,
            SituacaoPeriodoAquisitivoDecimoTerceiro.EM_ANDAMENTO,
            SituacaoPeriodoAquisitivoDecimoTerceiro.QUITADO_PARCIALMENTE).each {
        periodovenc ->
            if (periodovenc.anoExercicio == Datas.ano(calculo.competencia)) {
                periodoAtual = periodovenc
            }
    }
} else {
    vlrrefproc = Funcoes.avos13(12)
    vlrreffgts = Funcoes.avos13(12, true)
}
if (vlrrefproc <= 0) {
    suspender \"Não há avos adquiridos no período aquisitivo de décimo terceiro\"
}
def vvar = Lancamentos.valor(evento)
if (vvar >= 0) {
    valorCalculado = vvar
    valorReferencia = vvar
    vlrcalcfgts = vvar * vlrreffgts / vlrrefproc
} else {
    double base = Eventos.valor(29) + Eventos.valor(30) + Eventos.valor(233) //apenas para gerar dependência
    valorReferencia = vlrrefproc
    double valorMedia
    if (calculo.dataRescisao && TipoProcessamento.RESCISAO.equals(calculo.tipoProcessamento)) {
        valorMedia = mediaVantagem.calcular(periodoAtual, valorReferencia)
    } else {
        valorMedia = mediaVantagem.calcular(valorReferencia)
    }
    valorCalculado = valorMedia
    vlrcalcfgts = valorMedia * vlrreffgts / vlrrefproc
}
Bases.compor(valorCalculado,
        Bases.IRRF13,
        Bases.INSS13,
        Bases.PREVEST13,
        Bases.FUNDASS13,
        Bases.FUNDPREV13,
        Bases.FUNDFIN13)
Bases.compor(vlrcalcfgts, Bases.FGTS13)
