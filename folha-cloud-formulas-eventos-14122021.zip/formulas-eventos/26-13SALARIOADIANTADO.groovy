def valorFerias = Funcoes.replicaFeriasNaFolhaMensal(evento.codigo)
valorCalculado = valorFerias.valor
valorReferencia = valorFerias.referencia
if (TipoProcessamento.DECIMO_TERCEIRO_SALARIO.equals(calculo.tipoProcessamento) || TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento)) {
    if (folha.folhaPagamento) {
        if (TipoMatricula.PENSIONISTA.equals(matricula.tipo)) {
            suspender \"Este cálculo não é executado para pensionistas\"
        }
        boolean recebeDecimoTerceiro = Funcoes.recebeDecimoTerceiro()
        if (!recebeDecimoTerceiro) {
            suspender \"A matrícula não tem direito a receber décimo terceiro\"
        }
        if (calculo.pagarDecimoTerceiroFerias && TipoProcessamento.FERIAS.equals(calculo.tipoProcessamento)) {
            if (periodoAquisitivoDecimoTerceiro.totalMovimentacoes > 0) {
                suspender \"Não é possível realizar o pagamento do décimo terceiro salário adiantado em férias pois já existem movimentações lançadas no período aquisitivo de décimo terceiro\"
            }
        } else {
            if (!periodoAquisitivoDecimoTerceiro.situacao.equals(SituacaoPeriodoAquisitivoDecimoTerceiro.EM_ANDAMENTO) && !periodoAquisitivoDecimoTerceiro.situacao.equals(SituacaoPeriodoAquisitivoDecimoTerceiro.ATRASADO)) {
                suspender \"O período aquisitivo de décimo terceiro já foi quitado ou está com situação diferente de 'Em andamento' ou 'Atrasado'\"
            }
        }
        if (TipoMatricula.APOSENTADO.equals(matricula.tipo)) {
            if (Funcoes.diasaposent() > 0) {
                if (aposentado.dataCessacaoAposentadoria != null) {
                    if (Datas.data(calculo.competencia.ano, calculo.competencia.mes, 1) == Datas.data(aposentado.dataCessacaoAposentadoria.ano, aposentado.dataCessacaoAposentadoria.mes, 1)) {
                        valorReferencia = Funcoes.avos13(Datas.mes(calculo.competencia))
                    }
                } else {
                    valorReferencia = Funcoes.avos13(12)
                }
            }
        } else {
            if (Funcoes.dtrescisao()) {
                valorReferencia = Funcoes.avos13(Datas.mes(calculo.competencia))
            } else {
                valorReferencia = Funcoes.avos13(12)
            }
        }
        def vvar = Lancamentos.valor(evento)
        if (vvar > 0) {
            valorCalculado = vvar
        } else {
            def salario = Funcoes.remuneracao(matricula.tipo).valor
            valorCalculado = salario * valorReferencia / 12 * evento.taxa / 100
        }
        Bases.compor(valorCalculado, Bases.FGTS13)
    }
}
